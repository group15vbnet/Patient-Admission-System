﻿Public Class SplashScreen
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Panel2.Width += 2
        If Panel2.Right >= Panel1.Width Then
            Timer1.Stop()
            Form1.Show()
            Me.Hide()
        End If
    End Sub
End Class