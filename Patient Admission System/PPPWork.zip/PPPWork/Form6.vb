﻿Imports System.Data.SqlClient

Public Class Form6

    Private connectionString As String = "Server=EPHRAIM;Database=TheWork;Trusted_Connection=True;"
    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDoctors()
        LoadAssignments()

        SetRoundedControl(Panel1, 20)
        SetRoundedControl(Panel2, 20)
        SetRoundedControl(Panel3, 20)
        SetRoundedControl(panel4, 20)

    End Sub


    Private Sub SetRoundedControl(ctrl As Control, cornerRadius As Integer)
        Dim path As New Drawing2D.GraphicsPath()
        path.StartFigure()
        path.AddArc(New Rectangle(0, 0, cornerRadius, cornerRadius), 180, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, 0, cornerRadius, cornerRadius), -90, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 0, 90)
        path.AddArc(New Rectangle(0, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 90, 90)
        path.CloseFigure()
        ctrl.Region = New Region(path)
    End Sub





    Private Sub LoadDoctors()
        Dim query As String = "SELECT DISTINCT DoctorName FROM Doctors" ' Make sure you have a Doctors table
        Try
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    conn.Open()
                    Dim reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        cmbDoctor.Items.Add(reader("DoctorName").ToString())
                    End While
                    conn.Close()
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading doctors: " & ex.Message)
        End Try
    End Sub
    Private Sub btnAssign_Click(sender As Object, e As EventArgs) Handles btnAssign.Click
        If txtPatientID.Text = "" Or cmbDoctor.Text = "" Then
            MessageBox.Show("Please enter Patient ID and select a doctor.")
            Exit Sub
        End If

        Dim query As String = "UPDATE Patients SET AssignedDoctor = @Doctor WHERE PatientID = @PatientID"
        Try
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@Doctor", cmbDoctor.Text.Trim())
                    cmd.Parameters.AddWithValue("@PatientID", txtPatientID.Text.Trim())
                    conn.Open()
                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                    conn.Close()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Doctor assigned successfully!")
                        LoadAssignments()
                    Else
                        MessageBox.Show("Failed to assign doctor. Patient not found.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Database error: " & ex.Message)
        End Try
    End Sub

    Private Sub LoadAssignments()
        Dim query As String = "SELECT PatientID, FirstName, LastName, AssignedDoctor FROM Patients"
        Try
            Using conn As New SqlConnection(connectionString)
                Using adapter As New SqlDataAdapter(query, conn)
                    Dim table As New DataTable()
                    conn.Open()
                    adapter.Fill(table)
                    conn.Close()
                    dgvAssignments.DataSource = table
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading assignments: " & ex.Message)
        End Try
    End Sub

    Private Sub bu_Click(sender As Object, e As EventArgs) Handles bu.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class