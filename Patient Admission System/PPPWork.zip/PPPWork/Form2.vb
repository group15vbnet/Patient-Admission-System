﻿Public Class Form2
    Private Sub btnAddPatient_Click(sender As Object, e As EventArgs) Handles btnAddPatient.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub btnDelPatient_Click(sender As Object, e As EventArgs) Handles btnDelPatient.Click
        Form4.Show()
        Me.Hide()
    End Sub

    Private Sub btnUpdatePatient_Click(sender As Object, e As EventArgs) Handles btnUpdatePatient.Click
        Form5.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form6.Show()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetRoundedControl(Panel1, 20)
        SetRoundedControl(Panel2, 20)
        SetRoundedControl(Panel3, 20)

    End Sub



    Private Sub SetRoundedControl(ctrl As Control, cornerRadius As Integer)
        Dim path As New Drawing2D.GraphicsPath()
        path.StartFigure()
        path.AddArc(New Rectangle(0, 0, cornerRadius, cornerRadius), 180, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, 0, cornerRadius, cornerRadius), -90, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 0, 90)
        path.AddArc(New Rectangle(0, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 90, 90)
        path.CloseFigure()
        ctrl.Region = New Region(path)
    End Sub
End Class