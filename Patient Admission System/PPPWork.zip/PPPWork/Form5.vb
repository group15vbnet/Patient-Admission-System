﻿Imports System.Data.SqlClient

Public Class Form5
    Private connectionString As String = "Server=EPHRAIM;Database=TheWork;Trusted_Connection=True;"
    Private Sub Label8_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If dgvPatients.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select a record to edit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        txtPatientID.Text = dgvPatients.SelectedRows(0).Cells("PatientID").Value.ToString()
        txtFirstName.Text = dgvPatients.SelectedRows(0).Cells("FirstName").Value.ToString()
        txtLastName.Text = dgvPatients.SelectedRows(0).Cells("LastName").Value.ToString()
        dtpDOB.Text = dgvPatients.SelectedRows(0).Cells("DateOfBirth").Value.ToString()
        cmbGender.Text = dgvPatients.SelectedRows(0).Cells("Gender").Value.ToString()
        txtContact.Text = dgvPatients.SelectedRows(0).Cells("ContactNumber").Value.ToString()
        txtAddress.Text = dgvPatients.SelectedRows(0).Cells("Address").Value.ToString()
        txtMedicalCondition.Text = dgvPatients.SelectedRows(0).Cells("MedicalCondition").Value.ToString()

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Check if Patient ID is entered
        If String.IsNullOrWhiteSpace(txtPatientID.Text) Then
            MessageBox.Show("No patient selected. Please edit a record first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Validate if Patient ID is a number
        Dim patientID As Integer
        If Not Integer.TryParse(txtPatientID.Text.Trim(), patientID) Then
            MessageBox.Show("Invalid Patient ID. Please enter a valid number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Update Query (Removed `PatientID=@PatientID` from SET)
        Dim query As String = "UPDATE Patients SET FirstName=@FirstName, LastName=@LastName, DateOfBirth=@DateOfBirth, Gender=@Gender, 
                           ContactNumber=@ContactNumber, Address=@Address, MedicalCondition=@MedicalCondition WHERE PatientID=@PatientID"

        Try
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PatientID", patientID)
                    cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text.Trim())
                    cmd.Parameters.AddWithValue("@LastName", txtLastName.Text.Trim())
                    cmd.Parameters.AddWithValue("@DateOfBirth", dtpDOB.Value.Date) ' Use .Value instead of .Text
                    cmd.Parameters.AddWithValue("@Gender", cmbGender.Text.Trim())
                    cmd.Parameters.AddWithValue("@ContactNumber", txtContact.Text.Trim())
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim())
                    cmd.Parameters.AddWithValue("@MedicalCondition", txtMedicalCondition.Text.Trim())

                    conn.Open()
                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                    conn.Close()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Patient record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        LoadPatientRecords()  ' Refresh DataGridView
                    Else
                        MessageBox.Show("Update failed. Patient not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Database Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadPatientRecords()

        cmbGender.Items.Add("Male")
        cmbGender.Items.Add("Female")

        SetRoundedControl(Panel1, 20)
        SetRoundedControl(Panel2, 20)
        SetRoundedControl(Panel3, 20)
        SetRoundedControl(Panel4, 20)

    End Sub


    Private Sub SetRoundedControl(ctrl As Control, cornerRadius As Integer)
        Dim path As New Drawing2D.GraphicsPath()
        path.StartFigure()
        path.AddArc(New Rectangle(0, 0, cornerRadius, cornerRadius), 180, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, 0, cornerRadius, cornerRadius), -90, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 0, 90)
        path.AddArc(New Rectangle(0, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 90, 90)
        path.CloseFigure()
        ctrl.Region = New Region(path)
    End Sub


    Private Sub LoadPatientRecords()
        Dim query As String = "SELECT * FROM Patients"

        Try
            Using conn As New SqlConnection(connectionString)
                Using adapter As New SqlDataAdapter(query, conn)
                    Dim table As New DataTable()
                    conn.Open()
                    adapter.Fill(table)
                    conn.Close()

                    ' Display Records in DataGridView
                    dgvPatients.DataSource = table
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Database Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub cmbGender_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbGender.SelectedIndexChanged

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Form2.Show()
    End Sub
End Class