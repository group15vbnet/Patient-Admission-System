﻿Imports System.Data.SqlClient

Public Class Form4

    Private connectionString As String = "Server=EPHRAIM;Database=TheWork;Trusted_Connection=True;"
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim patientID As String = txtSearchPatientID.Text.Trim()

        If patientID = "" Then
            MessageBox.Show("Please enter a Patient ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim query As String = "SELECT * FROM Patients WHERE PatientID = @PatientID"

        Try
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PatientID", patientID)
                    Dim adapter As New SqlDataAdapter(cmd)
                    Dim table As New DataTable()

                    conn.Open()
                    adapter.Fill(table)
                    conn.Close()

                    ' Display the result in DataGridView
                    dgvPatientRecords.DataSource = table

                    If table.Rows.Count = 0 Then
                        MessageBox.Show("No patient found with this ID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Database Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try




    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim patientID As String = txtSearchPatientID.Text.Trim()

        If patientID = "" Then
            MessageBox.Show("Please enter a Patient ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Confirm Deletion
        Dim confirm As DialogResult = MessageBox.Show("Are you sure you want to delete this patient?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
        If confirm = DialogResult.No Then Exit Sub

        ' SQL Query to Delete Patient
        Dim query As String = "DELETE FROM Patients WHERE PatientID = @PatientID"

        Try
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PatientID", patientID)

                    conn.Open()
                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                    conn.Close()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Patient deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        dgvPatientRecords.DataSource = Nothing  ' Clear DataGridView
                        txtSearchPatientID.Clear()
                    Else
                        MessageBox.Show("No patient found with this ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Database Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Form2.Show()
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetRoundedControl(Panel1, 20)
        SetRoundedControl(Panel2, 20)
        SetRoundedControl(Panel3, 20)
        SetRoundedControl(Panel4, 20)

    End Sub

    Private Sub SetRoundedControl(ctrl As Control, cornerRadius As Integer)
        Dim path As New Drawing2D.GraphicsPath()
        path.StartFigure()
        path.AddArc(New Rectangle(0, 0, cornerRadius, cornerRadius), 180, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, 0, cornerRadius, cornerRadius), -90, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 0, 90)
        path.AddArc(New Rectangle(0, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 90, 90)
        path.CloseFigure()
        ctrl.Region = New Region(path)
    End Sub
End Class