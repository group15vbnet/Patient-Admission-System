﻿Public Class Form1
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim userName As String
        Dim Password As String
        userName = "Admin"
        Password = "123456"
        Try
            If txtUserID.Text = userName And txtPassCode.Text = Password Then
                Form2.Show()
                Me.Hide()

            Else
                txtUserID.Clear()

                txtPassCode.Clear()
                txtUserID.Focus()
                MessageBox.Show("Invalid Username or Password", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error)

            End If
        Catch ex As Exception
            ' Handle exception here
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SetRoundedControl(Panel1, 20)
        SetRoundedControl(Panel2, 20)

    End Sub


    Private Sub SetRoundedControl(ctrl As Control, cornerRadius As Integer)
        Dim path As New Drawing2D.GraphicsPath()
        path.StartFigure()
        path.AddArc(New Rectangle(0, 0, cornerRadius, cornerRadius), 180, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, 0, cornerRadius, cornerRadius), -90, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 0, 90)
        path.AddArc(New Rectangle(0, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 90, 90)
        path.CloseFigure()
        ctrl.Region = New Region(path)
    End Sub




    Private Sub txtPassCode_TextChanged(sender As Object, e As EventArgs) Handles txtPassCode.TextChanged
        txtPassCode.PasswordChar = "*"
    End Sub
End Class
