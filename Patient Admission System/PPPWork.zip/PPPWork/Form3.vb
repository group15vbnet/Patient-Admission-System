﻿Imports System.Data.SqlClient

Public Class Form3
    Private connectionString As String = "Server=EPHRAIM;Database=TheWork;Trusted_Connection=True;"
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim firstName As String = txtFirstName.Text.Trim()
        Dim lastName As String = txtLastName.Text.Trim()
        Dim dob As Date = dtpDOB.Value
        Dim gender As String = cmbGender.SelectedItem.ToString()
        Dim contact As String = txtContact.Text.Trim()
        Dim address As String = txtAddress.Text.Trim()
        Dim emergencyContact As String = txtEmergency.Text.Trim()
        Dim medicalCondition As String = txtMedicalCondition.Text.Trim()
        Dim admissionDate As Date = dtpAdmissionDate.Value

        If firstName = "" Or lastName = "" Or contact = "" Or address = "" Or emergencyContact = "" Or medicalCondition = "" Then
            MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If





        Dim query As String = "INSERT INTO Patients (FirstName, LastName, DateOfBirth, Gender, ContactNumber, Address, EmergencyContact, MedicalCondition, AdmissionDate) 
                               VALUES (@FirstName, @LastName, @DateOfBirth, @Gender, @ContactNumber, @Address, @EmergencyContact, @MedicalCondition, @AdmissionDate)"

        Try
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    ' Add values to parameters
                    cmd.Parameters.AddWithValue("@FirstName", firstName)
                    cmd.Parameters.AddWithValue("@LastName", lastName)
                    cmd.Parameters.AddWithValue("@DateOfBirth", dob)
                    cmd.Parameters.AddWithValue("@Gender", gender)
                    cmd.Parameters.AddWithValue("@ContactNumber", contact)
                    cmd.Parameters.AddWithValue("@Address", address)
                    cmd.Parameters.AddWithValue("@EmergencyContact", emergencyContact)
                    cmd.Parameters.AddWithValue("@MedicalCondition", medicalCondition)
                    cmd.Parameters.AddWithValue("@AdmissionDate", admissionDate)

                    ' Open connection and execute query
                    conn.Open()
                    cmd.ExecuteNonQuery()
                    conn.Close()

                    MessageBox.Show("Patient added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)



                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try


    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtFirstName.Clear()
        txtLastName.Clear()
        txtContact.Clear()
        txtAddress.Clear()
        txtEmergency.Clear()
        txtMedicalCondition.Clear()
        cmbGender.SelectedIndex = -1
        dtpDOB.Value = DateTime.Now
        dtpAdmissionDate.Value = DateTime.Now

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Form2.Show()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbGender.Items.Add("Male")
        cmbGender.Items.Add("Female")
        cmbGender.SelectedIndex = 0


        ' Set rounded corners for panels
        SetRoundedControl(Panel1, 20)
        SetRoundedControl(Panel2, 20)
        SetRoundedControl(Panel3, 20)
    End Sub



    Private Sub SetRoundedControl(ctrl As Control, cornerRadius As Integer)
        Dim path As New Drawing2D.GraphicsPath()
        path.StartFigure()
        path.AddArc(New Rectangle(0, 0, cornerRadius, cornerRadius), 180, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, 0, cornerRadius, cornerRadius), -90, 90)
        path.AddArc(New Rectangle(ctrl.Width - cornerRadius, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 0, 90)
        path.AddArc(New Rectangle(0, ctrl.Height - cornerRadius, cornerRadius, cornerRadius), 90, 90)
        path.CloseFigure()
        ctrl.Region = New Region(path)
    End Sub

    Private Sub cmbGender_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbGender.SelectedIndexChanged

    End Sub
End Class